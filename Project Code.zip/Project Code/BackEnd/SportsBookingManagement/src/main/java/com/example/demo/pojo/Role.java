package com.example.demo.pojo;

public enum Role {
	ROLE_ACADEMY,ROLE_PLAYER,ROLE_ADMIN,ROLE_USER
}
