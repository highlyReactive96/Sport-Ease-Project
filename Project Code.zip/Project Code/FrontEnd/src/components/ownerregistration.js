//import '../node_modules/bootstrap/dist/css/bootstrap.css'

//import registerAsOwner from './components/registerAsOwner';
// import registerAsOwner from './components/registerAsOwner';
// import RegisterOwner from './components/registerasowner';
// import RegisterOwner from './components/registerowner';
import RegisterOwner from './registerowner';

// import ;
//import LoginForm from "./components/loginForm";

function OwnerRegistration() {
return (
<>
<div className="container mt-5">
<div className="row">
<div className="col-md-6 offset-md-3">
<RegisterOwner></RegisterOwner>
</div>
</div>
</div>
</>
);
}

export default OwnerRegistration;




































// export default ownerregistration;