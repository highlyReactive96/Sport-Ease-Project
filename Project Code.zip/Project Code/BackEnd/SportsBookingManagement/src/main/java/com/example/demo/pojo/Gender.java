package com.example.demo.pojo;

public enum Gender {
	
	MALE,FEMALE,OTHER

}
