import CitiesList from "./components/users/citiesList";

function Users() {
    return ( 
        <CitiesList></CitiesList>
     );
}

export default Users;