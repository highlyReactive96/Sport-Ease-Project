import LoginForm from "./loginForm";
import TopHeader from "./topHeader";
function Header() {
    return (
        <>
            <div className = "row">
                <div className = "col-sm-8">
                    <br></br>
                    <br></br>
                    <br></br>
                   <TopHeader></TopHeader>
                </div>
            </div>
        </>
    );
}

export default Header;