const ImageSlide=[
    {
        url:'./images/football-2.jpg',
        title:"Football",
        body:"If what you did yesterday seems big, you haven't done anything today. –Lou Holtz."
    },
    {
        url:'./images/badminton-1.jpg',
        title:"Badminton",
        body:"Serve it, smash it, win it, love it! "
    },
    {
        url:'./images/cricket-1.jpg',
        title:"Cricket",
        body:" “Life is like Cricket, Take Infinite Wickets and Face the Pace to Win the Race.”"
    },
    {
        url:'./images/tennis.jpg',
        title:"Tennis",
        body:"“Losing is not my enemy, fear of losing is my enemy.”"
    },
    {
        url:'./images/tabletennis.jpg',
        title:"Table-Tennis",
        body:"The best time to play ping pong is when you know – Winning is not everything! "
    }
]
export default ImageSlide